"""Authorized 30-minute QOS-only retry, then read-only monitoring; never retrain."""
from datetime import datetime, timedelta, timezone
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time
import traceback

ROOT = Path('/adialab/usr/khaled/SAMTOK_DIR/AVMUR/baselines/setup/unime_rerun_20260925_02')
INTERVAL = 1800


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def utc():
    return datetime.now(timezone.utc)


def classify(response):
    """Never interpret an ambiguous submission as permission for another job."""
    code, out, err = response['returncode'], response['stdout'], response['stderr']
    if code == 0 and re.fullmatch(r'[1-9][0-9]*(?:;[^\s]+)?\s*', out):
        return 'accepted', out.strip().split(';')[0]
    allowed = ('sbatch: error: QOSMaxSubmitJobPerUserLimit',
               "sbatch: error: Batch job submission failed: Job violates accounting/QOS policy (job submit limit, user's size and/or time limits)")
    lines = [line.strip() for line in err.splitlines() if line.strip()]
    if code != 0 and not out.strip() and allowed[0] in lines and all(line in allowed for line in lines):
        return 'quota_rejected', None
    return 'ambiguous_or_other_failure', None


def attempt_paths(number):
    suffix = '' if number == 1 else '_ATTEMPT' + str(number)
    return ROOT / ('SUBMIT_INTENT' + suffix + '.json'), ROOT / ('SBATCH_RESPONSE' + suffix + '.json')


def latest_rejection():
    numbers = set()
    for path in ROOT.iterdir():
        match = re.fullmatch(r'(?:SUBMIT_INTENT|SBATCH_RESPONSE)(?:_ATTEMPT([0-9]+))?\.json', path.name)
        if match:
            numbers.add(int(match.group(1) or 1))
    if not numbers or sorted(numbers) != list(range(1, max(numbers) + 1)):
        raise RuntimeError('Missing or noncontiguous prior submission audit records')
    latest = None
    for number in sorted(numbers):
        intent, response = attempt_paths(number)
        if not intent.is_file() or not response.is_file():
            raise RuntimeError('Orphan submission intent/response; never retry an unknown outcome')
        value = json.loads(response.read_text())
        if classify(value)[0] != 'quota_rejected':
            raise RuntimeError('Prior attempt was accepted, ambiguous, or not a quota rejection')
        latest = value
    return max(numbers), latest


def next_due(response):
    instant = datetime.fromisoformat(response['utc'])
    if instant.tzinfo is None:
        raise ValueError('Submission response time must include timezone')
    return instant + timedelta(seconds=INTERVAL)


def atomic_json(name, value):
    temporary = ROOT / (name + '.' + str(os.getpid()) + '.tmp')
    with temporary.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, ROOT / name)


def status(phase, **fields):
    value = dict(phase=phase, utc=utc().isoformat(), pid=os.getpid(), **fields)
    atomic_json('RETRY_STATUS.json', value)
    return value


def event(kind, **fields):
    value = dict(fields)
    if 'utc' in value:
        value['reported_utc'] = value.pop('utc')
    value.update(event=kind, utc=utc().isoformat())
    with (ROOT / 'RETRY_EVENTS.jsonl').open('a') as handle:
        handle.write(json.dumps(value, allow_nan=False) + '\n')
        handle.flush()
        os.fsync(handle.fileno())
    print(json.dumps(value), flush=True)


def account_guard(m):
    result = subprocess.run(['sacct', '-X', '-n', '-P', '-u', 'khaled',
        '--starttime', '2026-09-24T15:30:00', '--format=JobIDRaw,JobName%100,State,Comment%200'],
        capture_output=True, text=True, check=True, timeout=30)
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        fields = line.split('|')
        if len(fields) < 4 or not fields[0].strip().isdigit():
            raise RuntimeError('Malformed accounting response; refusing submission: ' + line)
        # Exempt only explicitly approved, still-cancelled predecessors.
        # A matching NEW tag is never exempt, even on an old job ID.
        if (fields[0].strip() in m.CANCELLED_PREDECESSORS
                and fields[2].strip().startswith('CANCELLED') and m.TAG not in fields[3]):
            continue
        if fields[1].strip() in ('vxc', 'vcx') or m.TAG in fields[3]:
            raise RuntimeError('Existing matching scheduler job without receipt; reconcile, never duplicate: ' + line)
    return result.stdout


def attempt(m, number):
    if (ROOT / 'SUBMITTED.json').exists() or (ROOT / 'SUBMITTED.json').is_symlink():
        raise RuntimeError('Submission already accepted; do not submit again')
    manifest_sha = m.verify_source()
    pretrain = m.verify_pretraining()
    smoke = m.verify_old_smoke()
    m.cancelled_predecessors()
    queue = m.check_queue()
    m.fresh_run_path()
    accounting = account_guard(m)
    command = m.submission_command()
    intent, response_path = attempt_paths(number)
    m.exclusive(intent, dict(created_utc=m.utc(), command=command, manifest_sha256=manifest_sha,
        pretraining=pretrain, prior_smoke=smoke, queue=queue, accounting=accounting,
        user_authorized='retry every30minutes untilqueued, then monitor training',
        controller_sha256=m.sha(Path(__file__)), interval_seconds=INTERVAL, attempt=number))
    env = {key: value for key, value in os.environ.items() if not key.startswith('SBATCH_')}
    try:
        result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)
    except BaseException as error:
        # Intent remains authoritative proof that submission may have happened.
        event('submission_unknown', attempt=number, error=repr(error))
        raise
    response = dict(utc=m.utc(), returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    m.exclusive(response_path, response)
    outcome, job = classify(response)
    event('submission_response', attempt=number, outcome=outcome, job_id=job, response=response)
    if outcome == 'accepted':
        m.exclusive(ROOT / 'SUBMITTED.json', dict(job_id=job, manifest_sha256=manifest_sha,
            created_utc=m.utc(), command=command, attempt=number))
        return job
    if outcome != 'quota_rejected':
        raise RuntimeError('Submission result was not a proven quota rejection; no further retry')
    return None


def monitor(m):
    receipt = m.read(ROOT / 'SUBMITTED.json')
    if receipt['manifest_sha256'] != m.verify_source() or receipt['command'] != m.submission_command():
        raise RuntimeError('Accepted receipt differs from approved launch')
    observer = load('authorized_epoch_observer', ROOT / 'watch_epochs.py')
    job = observer.resolve_job_id()
    seen = {'finetune': 0}
    event('monitoring_accepted_job', job_id=job, no_more_submissions=True)
    while True:
        try:
            trial_seen = dict(seen)
            snapshot = observer.safe_json(observer.snapshot(trial_seen, job))
            atomic_json('MONITOR_LATEST.json', snapshot)
            status('monitoring', job_id=job, terminal=snapshot['terminal'],
                   fine_tuning_epochs=snapshot['completed_counts']['finetune'])
            for row in snapshot['new_epochs']:
                event('completed_epoch', job_id=job, metrics=row)
            seen = trial_seen
            if snapshot['terminal']:
                event('job_terminal', job_id=job, state=snapshot.get('terminal_state'),
                      exit_code=snapshot.get('exit_code'), automatic_resubmission=False)
                status('job_terminal', job_id=job, state=snapshot.get('terminal_state'),
                       exit_code=snapshot.get('exit_code'))
                return
        except (OSError, subprocess.SubprocessError) as error:
            # An observation failure is not job failure and never causes submission.
            event('observation_error', job_id=job, error=repr(error))
            status('monitor_observation_error', job_id=job, error=repr(error))
        time.sleep(30)


def main():
    if Path(__file__).resolve().parent != ROOT or ROOT.resolve() != ROOT:
        raise RuntimeError('Wrong controller location')
    with (ROOT / 'RETRY_CONTROLLER.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        proof = dict(pid=os.getpid(), started_utc=utc().isoformat(),
            start_ticks=Path('/proc/self/stat').read_text().split()[21],
            command=str(Path(__file__).resolve()), interval_seconds=INTERVAL)
        atomic_json('RETRY_CONTROLLER_PID.json', proof)
        m = load('approved_restart_launcher', ROOT / 'launcher.py')
        event('controller_started', **proof)
        try:
            m.verify_source()
            while not (ROOT / 'SUBMITTED.json').exists():
                number, response = latest_rejection()
                due = next_due(response)
                status('waiting_to_retry', last_attempt=number, next_attempt_utc=due.isoformat())
                while utc() < due:
                    if (ROOT / 'SUBMITTED.json').exists():
                        break
                    time.sleep(min(30, max(.1, (due - utc()).total_seconds())))
                if (ROOT / 'SUBMITTED.json').exists():
                    break
                status('submitting', attempt=number + 1)
                attempt(m, number + 1)
            monitor(m)
        except BaseException:
            failure = traceback.format_exc()
            status('stopped_for_review', traceback=failure)
            event('controller_stopped_for_review', traceback=failure)
            raise


if __name__ == '__main__':
    main()
