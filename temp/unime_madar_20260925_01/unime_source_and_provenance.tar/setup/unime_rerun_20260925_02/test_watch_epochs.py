import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

path = Path(__file__).with_name('watch_epochs.py')
spec = importlib.util.spec_from_file_location('vxc_rerun_readonly_watch', path)
watch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(watch)


def lines(rows):
    return b''.join(json.dumps(row).encode() + b'\n' for row in rows)


class ObserverTests(unittest.TestCase):
    def test_nonfinite_values_visible_and_serializable(self):
        value = {'loss': float('nan'), 'nested': [float('inf')]}
        self.assertEqual(watch.safe_json(value), {'loss': 'nan', 'nested': ['inf']})
        self.assertEqual(watch.nonfinite_fields(value), ['loss', 'nested[0]'])
        json.dumps(watch.safe_json(value), allow_nan=False)

    def test_only_completed_training_epochs(self):
        raw = lines([{'type': 'config'}, {'type': 'train', 'epoch': 1},
                     {'type': 'val', 'epoch': 1}, {'type': 'train', 'epoch': 2}])
        self.assertEqual([x['epoch'] for x in watch.epoch_records(raw)], [1, 2])

    def test_partial_json_not_completion(self):
        self.assertEqual(watch.epoch_records(b'{"type":"train","epoch":1}'), [])

    def test_invalid_or_noncontiguous_epochs_rejected(self):
        for epochs in ([1, 1], [1, 3], [2], [True], [1.0], [0], [601]):
            with self.subTest(epochs=epochs), self.assertRaises(ValueError):
                watch.epoch_records(lines([{'type': 'train', 'epoch': e} for e in epochs]))

    def test_malformed_complete_records_rejected(self):
        for raw in (b'{oops}\n', b'[]\n'):
            with self.assertRaises(ValueError):
                watch.epoch_records(raw)

    def test_validation_bar_is_not_training_completion(self):
        raw = (b'\rEpoch 460/600: 100%|xxx| 250/250 [01:09]\r'
               b'\x1b[32mValidation Epoch 460: 50%|xx| 62/125\x1b[0m\r')
        self.assertTrue(watch.last_bar(raw).startswith('Epoch 460/600:'))
        self.assertTrue(watch.last_finetune_activity(raw).startswith('Validation Epoch 460:'))
        self.assertEqual(watch.epoch_records(lines([{'type': 'val', 'epoch': 460}])), [])

    def test_training_supersedes_previous_validation(self):
        raw = b'Validation Epoch 460: 100%|xx| 125/125\rEpoch 461/600: 1%|x| 2/250\r'
        self.assertTrue(watch.last_finetune_activity(raw).startswith('Epoch 461/600:'))

    def test_job_ids_strictly_validated(self):
        for value in ('1', 12000):
            self.assertEqual(watch.valid_job_id(value), str(value))
        for value in ('', '0', '-1', '123_1', '123.batch', '1;scancel 1', True, 1.0, None, ' 12'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                watch.valid_job_id(value)

    def test_submission_receipt_and_explicit_id_must_agree(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(watch, 'LAUNCH', Path(directory)):
            self.assertEqual(watch.resolve_job_id('123'), '123')
            with self.assertRaises(ValueError):
                watch.resolve_job_id()
            (Path(directory) / 'SUBMITTED.json').write_text(json.dumps({'job_id': 123}))
            self.assertEqual(watch.resolve_job_id(), '123')
            self.assertEqual(watch.resolve_job_id('123'), '123')
            with self.assertRaises(ValueError):
                watch.resolve_job_id('124')

    def test_scheduler_query_timeout_is_not_success(self):
        with patch.object(watch.subprocess, 'run', side_effect=subprocess.TimeoutExpired('squeue', 20)):
            self.assertNotEqual(watch.query(['squeue']).returncode, 0)


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.run = Path(self.temp.name) / 'run'
        self.launch = Path(self.temp.name) / 'launch'
        self.run.mkdir()
        self.launch.mkdir()
        for name, value in (('RUN', self.run), ('LAUNCH', self.launch)):
            patcher = patch.object(watch, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)

    def snapshot_with(self, queue, accounting=None, seen=None):
        replies = [queue] + ([accounting] if accounting is not None else [])
        with patch.object(watch, 'query', side_effect=replies) as query:
            result = watch.snapshot(seen or {'finetune': 0}, '123')
        return result, query

    @staticmethod
    def reply(stdout='', returncode=0, stderr=''):
        return subprocess.CompletedProcess([], returncode, stdout, stderr)

    def test_queue_error_never_marks_terminal(self):
        result, query = self.snapshot_with(self.reply(returncode=1, stderr='timeout'))
        self.assertFalse(result['terminal'])
        self.assertEqual(query.call_count, 1)

    def test_terminal_requires_successful_exact_job_accounting(self):
        for accounting in (self.reply(), self.reply('123.batch|COMPLETED|0:0|01:00\n'),
                           self.reply('123|RUNNING|0:0|01:00\n'),
                           self.reply('123|FAILED|1:0|01:00\n', returncode=1),
                           self.reply('124|COMPLETED|0:0|01:00\n')):
            result, _ = self.snapshot_with(self.reply(), accounting)
            self.assertFalse(result['terminal'])

    def test_confirmed_cancellation_reports_correct_error_log(self):
        (self.launch / 'logs').mkdir()
        (self.launch / 'logs/vxc-123.err').write_text('SIGTERM received\n')
        result, _ = self.snapshot_with(self.reply(), self.reply('123|CANCELLED by 1008|0:0|01:00\n'))
        self.assertTrue(result['terminal'])
        self.assertEqual(result['terminal_state'], 'CANCELLED')
        self.assertIn('SIGTERM', result['stderr_tail'])

    def test_only_new_finetune_epochs_and_inherited_pretraining(self):
        path = self.run / watch.METRICS
        path.parent.mkdir(parents=True)
        path.write_bytes(lines([{'type': 'train', 'epoch': 1, 'loss': .9},
                                {'type': 'val', 'epoch': 1},
                                {'type': 'train', 'epoch': 2, 'loss': float('nan')}]))
        (self.launch / 'progress.json').write_text(json.dumps({'stage': 'finetune'}))
        seen = {'finetune': 1}
        result, _ = self.snapshot_with(self.reply('123|vxc|RUNNING'), seen=seen)
        self.assertEqual([(v['stage'], v['epoch']) for v in result['new_epochs']], [('finetune', 2)])
        self.assertEqual(result['completed_counts'], {'finetune': 2})
        self.assertEqual(result['inherited_pretraining']['completed_epochs'], 600)
        self.assertEqual(result['pipeline_progress'], {'stage': 'finetune'})
        self.assertEqual(result['warnings'][0]['nonfinite_fields'], ['loss'])
        self.assertEqual(seen, {'finetune': 2})
        json.dumps(watch.safe_json(result), allow_nan=False)

    def test_receipt_existence_does_not_prove_completion(self):
        (self.run / 'benchmark').mkdir()
        (self.run / 'benchmark/TEST_COMPLETE.json').write_text('{}')
        result, _ = self.snapshot_with(self.reply('123|vxc|RUNNING'))
        self.assertTrue(result['test_complete_receipt_exists'])
        self.assertFalse(result['terminal'])

    def test_cursor_cannot_skip_unavailable_history(self):
        with self.assertRaises(ValueError):
            self.snapshot_with(self.reply('123|vxc|RUNNING'), seen={'finetune': 1})

    def test_progress_partial_json_reported_not_terminal(self):
        (self.launch / 'progress.json').write_text('{')
        result, _ = self.snapshot_with(self.reply('123|vxc|RUNNING'))
        self.assertIn('progress_read_error', result['warnings'][0])
        self.assertFalse(result['terminal'])


if __name__ == '__main__':
    unittest.main()
