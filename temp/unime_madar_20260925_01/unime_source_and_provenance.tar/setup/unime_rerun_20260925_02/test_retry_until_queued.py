"""CPU-only retry-controller safeguards; never call a real scheduler or GPU."""
from contextlib import ExitStack
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch


spec = importlib.util.spec_from_file_location(
    'retry_controller_under_test', Path(__file__).with_name('retry_until_queued.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

QOS = ('sbatch: error: QOSMaxSubmitJobPerUserLimit\n'
       "sbatch: error: Batch job submission failed: Job violates accounting/QOS policy "
       "(job submit limit, user's size and/or time limits)\n")
STAMP = '2026-09-24T18:00:00+00:00'


def response(code=1, out='', err=QOS, stamp=STAMP):
    return dict(returncode=code, stdout=out, stderr=err, utc=stamp)


def write_json(path, value):
    with path.open('x') as handle:
        json.dump(value, handle)


class RetryTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.directory = self.stack.enter_context(tempfile.TemporaryDirectory(prefix='retry_test.'))
        self.root = Path(self.directory)
        self.stack.enter_context(patch.object(m, 'ROOT', self.root))

    def records(self, number=1, value=None):
        intent, result = m.attempt_paths(number)
        write_json(intent, dict(command=['sbatch'], attempt=number))
        write_json(result, value if value is not None else response())

    def launcher(self):
        command = ['sbatch', '--parsable', '--job-name=vxc', '--gres=gpu:nvidia_h200:1']
        return SimpleNamespace(
            TAG='unime_rerun_20260925_02',
            CANCELLED_PREDECESSORS=('11483', '11547', '11769', '11856'),
            verify_source=Mock(return_value='manifest'),
            verify_pretraining=Mock(return_value={'sha256': 'pretraining'}),
            verify_old_smoke=Mock(return_value={'sha256': 'smoke'}),
            cancelled_predecessors=Mock(), check_queue=Mock(return_value=[]),
            fresh_run_path=Mock(), submission_command=Mock(return_value=command),
            exclusive=write_json, utc=Mock(return_value=STAMP), sha=Mock(return_value='controller'),
            read=lambda path: json.loads(path.read_text()),
        )

    def attempt_mocks(self, result):
        guard = self.stack.enter_context(patch.object(m, 'account_guard', return_value=''))
        run = self.stack.enter_context(patch.object(m.subprocess, 'run', return_value=result))
        self.stack.enter_context(patch.object(m, 'event'))
        return guard, run

    def test_only_explicit_quota_rejection_is_retryable(self):
        self.assertEqual(m.classify(response()), ('quota_rejected', None))
        for item in (
            response(code=0), response(out='12345\n'), response(err=''),
            response(err=QOS + 'sbatch: error: unexpected failure\n'),
            response(err=QOS.splitlines()[1]),
            response(err='QOSMaxSubmitJobPerUserLimit'),
        ):
            with self.subTest(item=item):
                self.assertEqual(m.classify(item), ('ambiguous_or_other_failure', None))

    def test_success_id_and_cluster_parse(self):
        for out in ('12345\n', '12345;cluster-a\n'):
            self.assertEqual(m.classify(response(code=0, out=out, err='')), ('accepted', '12345'))
        for out in ('0\n', '12345_1\n', 'Submitted batch job 12345\n', '12345\n12346\n', ''):
            self.assertEqual(m.classify(response(code=0, out=out, err=''))[0], 'ambiguous_or_other_failure')

    def test_deadline_is_exactly_thirty_minutes_after_rejection(self):
        due = m.next_due(response())
        self.assertEqual(due, datetime(2026, 9, 24, 18, 30, tzinfo=timezone.utc))
        self.assertEqual((due - datetime.fromisoformat(STAMP)).total_seconds(), 1800)

    def test_timezone_offset_is_preserved_correctly(self):
        due = m.next_due(response(stamp='2026-09-24T22:00:00+04:00'))
        self.assertEqual(due.astimezone(timezone.utc), datetime(2026, 9, 24, 18, 30, tzinfo=timezone.utc))

    def test_naive_timestamp_rejected(self):
        with self.assertRaises(ValueError):
            m.next_due(response(stamp='2026-09-24T18:00:00'))

    def test_existing_attempt_names_and_latest_deadline_preserved(self):
        self.records()
        later = response(stamp='2026-09-24T18:40:00+00:00')
        self.records(2, later)
        before = {path.name: path.read_bytes() for path in self.root.iterdir()}
        number, result = m.latest_rejection()
        self.assertEqual(number, 2)
        self.assertEqual(result, later)
        self.assertEqual(m.next_due(result), datetime(2026, 9, 24, 19, 10, tzinfo=timezone.utc))
        self.assertEqual(before, {path.name: path.read_bytes() for path in self.root.iterdir()})

    def test_no_records_never_means_permission_to_submit(self):
        with self.assertRaisesRegex(RuntimeError, 'Missing'):
            m.latest_rejection()

    def test_noncontiguous_records_rejected(self):
        self.records(1)
        self.records(3)
        with self.assertRaisesRegex(RuntimeError, 'noncontiguous'):
            m.latest_rejection()

    def test_orphan_intent_stops(self):
        self.records(1)
        write_json(m.attempt_paths(2)[0], {'command': ['sbatch']})
        with self.assertRaisesRegex(RuntimeError, 'Orphan'):
            m.latest_rejection()

    def test_orphan_response_stops(self):
        write_json(m.attempt_paths(1)[1], response())
        with self.assertRaisesRegex(RuntimeError, 'Orphan'):
            m.latest_rejection()

    def test_prior_acceptance_without_receipt_never_retried(self):
        self.records(1, response(code=0, out='12345\n', err=''))
        with self.assertRaisesRegex(RuntimeError, 'accepted, ambiguous'):
            m.latest_rejection()

    def test_prior_ambiguous_response_never_retried(self):
        self.records(1, response(code=0, out='', err=''))
        with self.assertRaisesRegex(RuntimeError, 'accepted, ambiguous'):
            m.latest_rejection()

    def test_accounting_existing_job_by_name_stops_even_when_terminal(self):
        for state in ('PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED'):
            with self.subTest(state=state), patch.object(m.subprocess, 'run', return_value=
                    subprocess.CompletedProcess([], 0, f'12345|vxc|{state}|other-comment|\n', '')):
                with self.assertRaisesRegex(RuntimeError, 'Existing matching scheduler job'):
                    m.account_guard(self.launcher())

    def test_accounting_existing_job_by_tag_stops(self):
        result = subprocess.CompletedProcess([], 0,
            '12345|renamed|RUNNING|unime_rerun_20260925_02:fresh-finetune|\n', '')
        with patch.object(m.subprocess, 'run', return_value=result):
            with self.assertRaises(RuntimeError):
                m.account_guard(self.launcher())


    def test_only_known_cancelled_predecessor_is_exempt(self):
        result = subprocess.CompletedProcess([], 0,
            '11769|vxc|CANCELLED by 1008|unime_rerun_20260924_01:fresh-finetune|\n', '')
        with patch.object(m.subprocess, 'run', return_value=result):
            self.assertEqual(m.account_guard(self.launcher()), result.stdout)

    def test_known_predecessor_not_exempt_if_live_or_new_tag(self):
        for state, comment in (('RUNNING', 'old'), ('PENDING', 'old'),
                               ('COMPLETED', 'old'), ('FAILED', 'old'),
                               ('CANCELLED', 'unime_rerun_20260925_02:fresh-finetune')):
            result = subprocess.CompletedProcess([], 0, f'11769|vxc|{state}|{comment}|\n', '')
            with self.subTest(state=state, comment=comment), patch.object(
                    m.subprocess, 'run', return_value=result):
                with self.assertRaisesRegex(RuntimeError, 'Existing matching scheduler job'):
                    m.account_guard(self.launcher())


    def test_newly_cancelled_11856_only_exempt_without_new_tag(self):
        for state, comment, allowed in (
                ('CANCELLED by 1008', 'unime_rerun_20260925_01:fresh-finetune', True),
                ('RUNNING', 'old', False), ('PENDING', 'old', False),
                ('CANCELLED', 'unime_rerun_20260925_02:fresh-finetune', False)):
            result = subprocess.CompletedProcess([], 0, f'11856|vxc|{state}|{comment}|\n', '')
            with self.subTest(state=state, comment=comment), patch.object(
                    m.subprocess, 'run', return_value=result):
                if allowed:
                    self.assertEqual(m.account_guard(self.launcher()), result.stdout)
                else:
                    with self.assertRaisesRegex(RuntimeError, 'Existing matching scheduler job'):
                        m.account_guard(self.launcher())

    def test_accounting_unrelated_jobs_allowed(self):
        result = subprocess.CompletedProcess([], 0, '12345|other|RUNNING|other|\n', '')
        with patch.object(m.subprocess, 'run', return_value=result):
            self.assertEqual(m.account_guard(self.launcher()), result.stdout)

    def test_malformed_accounting_fails_closed(self):
        for output in ('unparseable output\n', '|vxc|RUNNING|comment|\n'):
            with self.subTest(output=output), patch.object(m.subprocess, 'run', return_value=
                    subprocess.CompletedProcess([], 0, output, '')):
                with self.assertRaises(RuntimeError):
                    m.account_guard(self.launcher())

    def test_existing_receipt_stops_before_scheduler_call(self):
        write_json(self.root / 'SUBMITTED.json', {'job_id': '12345'})
        launcher = self.launcher()
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 0, '99999\n', ''))
        with self.assertRaisesRegex(RuntimeError, 'already accepted'):
            m.attempt(launcher, 3)
        run.assert_not_called()
        launcher.verify_source.assert_not_called()

    def test_existing_attempt_intent_stops_before_scheduler_call(self):
        write_json(m.attempt_paths(3)[0], {'command': ['sbatch']})
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 0, '99999\n', ''))
        with self.assertRaises(FileExistsError):
            m.attempt(self.launcher(), 3)
        run.assert_not_called()

    def test_rejection_writes_durable_audit_without_receipt(self):
        launcher = self.launcher()
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 1, '', QOS))
        self.assertIsNone(m.attempt(launcher, 3))
        self.assertTrue(m.attempt_paths(3)[0].is_file())
        self.assertEqual(json.loads(m.attempt_paths(3)[1].read_text()), response())
        self.assertFalse((self.root / 'SUBMITTED.json').exists())
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.kwargs['timeout'], 60)

    def test_acceptance_writes_receipt_and_second_call_cannot_submit(self):
        launcher = self.launcher()
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 0, '12345;cluster\n', ''))
        self.assertEqual(m.attempt(launcher, 3), '12345')
        receipt = json.loads((self.root / 'SUBMITTED.json').read_text())
        self.assertEqual(receipt['job_id'], '12345')
        self.assertEqual(receipt['manifest_sha256'], 'manifest')
        self.assertEqual(receipt['command'], launcher.submission_command())
        with self.assertRaisesRegex(RuntimeError, 'already accepted'):
            m.attempt(launcher, 4)
        self.assertEqual(run.call_count, 1)

    def test_ambiguous_submission_is_logged_and_stops(self):
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 1, '12345\n', QOS))
        with self.assertRaisesRegex(RuntimeError, 'not a proven quota rejection'):
            m.attempt(self.launcher(), 3)
        self.assertTrue(m.attempt_paths(3)[1].is_file())
        self.assertFalse((self.root / 'SUBMITTED.json').exists())
        self.assertEqual(run.call_count, 1)

    def test_timeout_leaves_orphan_intent_and_never_creates_rejection(self):
        _, run = self.attempt_mocks(None)
        run.side_effect = subprocess.TimeoutExpired(['sbatch'], 60)
        with self.assertRaises(subprocess.TimeoutExpired):
            m.attempt(self.launcher(), 1)
        self.assertTrue(m.attempt_paths(1)[0].is_file())
        self.assertFalse(m.attempt_paths(1)[1].exists())
        with self.assertRaisesRegex(RuntimeError, 'Orphan'):
            m.latest_rejection()

    def test_frozen_inputs_failure_prevents_submission(self):
        for method in ('verify_source', 'verify_pretraining', 'verify_old_smoke',
                       'cancelled_predecessors', 'check_queue', 'fresh_run_path'):
            with self.subTest(method=method):
                launcher = self.launcher()
                getattr(launcher, method).side_effect = RuntimeError('guard failed')
                with patch.object(m.subprocess, 'run') as run:
                    with self.assertRaisesRegex(RuntimeError, 'guard failed'):
                        m.attempt(launcher, 3)
                    run.assert_not_called()
                self.assertFalse(m.attempt_paths(3)[0].exists())

    def test_sbatch_environment_overrides_are_removed(self):
        launcher = self.launcher()
        _, run = self.attempt_mocks(subprocess.CompletedProcess([], 1, '', QOS))
        with patch.dict(m.os.environ, {'SBATCH_GRES': 'gpu:8', 'UNCHANGED_TEST_VALUE': 'ok'}):
            m.attempt(launcher, 3)
        environment = run.call_args.kwargs['env']
        self.assertNotIn('SBATCH_GRES', environment)
        self.assertEqual(environment['UNCHANGED_TEST_VALUE'], 'ok')

    def test_controller_lock_is_exclusive(self):
        path = self.root / 'controller.lock'
        with path.open('a') as first, path.open('a') as second:
            m.fcntl.flock(first, m.fcntl.LOCK_EX | m.fcntl.LOCK_NB)
            with self.assertRaises(BlockingIOError):
                m.fcntl.flock(second, m.fcntl.LOCK_EX | m.fcntl.LOCK_NB)

    def test_monitor_does_not_resubmit_after_terminal_failure(self):
        launcher = self.launcher()
        write_json(self.root / 'SUBMITTED.json', dict(
            job_id='12345', manifest_sha256='manifest', command=launcher.submission_command()))
        observer = SimpleNamespace(resolve_job_id=lambda: '12345', safe_json=lambda value: value,
            snapshot=Mock(return_value=dict(terminal=True, terminal_state='FAILED', exit_code='1:0',
                                           completed_counts={'finetune': 2}, new_epochs=[])))
        with patch.object(m, 'load', return_value=observer), patch.object(m, 'event'), \
                patch.object(m, 'attempt') as attempt, patch.object(m, 'time') as clock:
            m.monitor(launcher)
        attempt.assert_not_called()
        clock.sleep.assert_not_called()
        self.assertEqual(json.loads((self.root / 'RETRY_STATUS.json').read_text())['phase'], 'job_terminal')

    def test_monitor_receipt_mismatch_stops_before_observer(self):
        launcher = self.launcher()
        write_json(self.root / 'SUBMITTED.json', dict(
            job_id='12345', manifest_sha256='different', command=launcher.submission_command()))
        with patch.object(m, 'load') as load:
            with self.assertRaisesRegex(RuntimeError, 'differs from approved launch'):
                m.monitor(launcher)
        load.assert_not_called()

    def test_monitor_io_failure_does_not_advance_epoch_cursor(self):
        launcher = self.launcher()
        write_json(self.root / 'SUBMITTED.json', dict(
            job_id='12345', manifest_sha256='manifest', command=launcher.submission_command()))
        cursors = []

        def snapshot(seen, job):
            cursors.append(seen['finetune'])
            seen['finetune'] = 1
            return dict(terminal=len(cursors) == 2, terminal_state='COMPLETED', exit_code='0:0',
                        completed_counts={'finetune': 1}, new_epochs=[{'epoch': 1}])

        original_atomic = m.atomic_json
        snapshot_writes = []

        def write_with_first_failure(name, value):
            if name == 'MONITOR_LATEST.json':
                snapshot_writes.append(name)
                if len(snapshot_writes) == 1:
                    raise OSError('temporary write failure')
            return original_atomic(name, value)

        observer = SimpleNamespace(resolve_job_id=lambda: '12345', safe_json=lambda value: value,
                                   snapshot=snapshot)
        with patch.object(m, 'load', return_value=observer), patch.object(m, 'event') as event, \
                patch.object(m, 'atomic_json', side_effect=write_with_first_failure), \
                patch.object(m.time, 'sleep'):
            m.monitor(launcher)
        self.assertEqual(cursors, [0, 0])
        self.assertEqual(sum(call.args[0] == 'completed_epoch' for call in event.call_args_list), 1)

    def test_event_accepts_response_timestamp_without_duplicate_keyword(self):
        m.event('submission_response', attempt=3, outcome='quota_rejected', job_id=None, **response())
        record = json.loads((self.root / 'RETRY_EVENTS.jsonl').read_text())
        self.assertEqual(record['event'], 'submission_response')
        self.assertEqual(record['returncode'], 1)


if __name__ == '__main__':
    unittest.main()
