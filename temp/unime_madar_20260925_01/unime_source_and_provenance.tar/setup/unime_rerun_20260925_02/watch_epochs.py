"""Read-only vxc observer: inherited pretraining, fresh fine-tuning, selection/test.

Never submits or modifies a job or its artifacts. Only complete fine-tuning
training records count as epochs; native validation is reported separately.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import re
import subprocess
import time

BASE = Path('/adialab/usr/khaled/SAMTOK_DIR/AVMUR/baselines')
RUN = BASE / 'artifacts/unime/benchmark_runs/unime_rerun_20260925_02'
LAUNCH = BASE / 'setup/unime_rerun_20260925_02'
PRETRAIN_SOURCE = BASE / 'artifacts/unime/benchmark_runs/unime_20260923_01'
METRICS = 'finetune/BRATS2023-40-Normal/UniME/UniME_metrics.jsonl'
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY',
            'NODE_FAIL', 'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED'}


def safe_json(value):
    """Make nonfinite metrics visible without emitting invalid JSON."""
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: safe_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [safe_json(item) for item in value]
    return value


def nonfinite_fields(value, prefix=''):
    if isinstance(value, float) and not math.isfinite(value):
        return [prefix]
    if isinstance(value, dict):
        return [path for key, item in value.items()
                for path in nonfinite_fields(item, f'{prefix}.{key}' if prefix else str(key))]
    if isinstance(value, list):
        return [path for index, item in enumerate(value)
                for path in nonfinite_fields(item, f'{prefix}[{index}]')]
    return []


def epoch_records(raw, kind='train'):
    """Validate a complete, contiguous epoch history; ignore an unfinished line."""
    records = []
    for line in raw.splitlines(keepends=True):
        if not line.endswith(b'\n'):
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError('JSONL record must be an object')
        if value.get('type') != kind:
            continue
        epoch = value.get('epoch')
        if type(epoch) is not int or not 1 <= epoch <= 600:
            raise ValueError('Invalid training epoch')
        if epoch != len(records) + 1:
            raise ValueError('Duplicate or noncontiguous training epoch records')
        records.append(value)
    return records


def last_bar(raw, prefix='Epoch '):
    lines = ANSI.sub('', raw.decode(errors='replace')).replace('\r', '\n').splitlines()
    bars = [line.strip() for line in lines
            if re.match(re.escape(prefix) + r'\d+/600:', line.strip())]
    return bars[-1] if bars else None


def last_finetune_activity(raw):
    lines = ANSI.sub('', raw.decode(errors='replace')).replace('\r', '\n').splitlines()
    bars = [line.strip() for line in lines
            if re.match(r'^(?:Epoch \d+/600|Validation Epoch \d+):', line.strip())]
    return bars[-1] if bars else None


def tail(path, count=128 * 1024):
    if not path.is_file():
        return b''
    with path.open('rb') as handle:
        handle.seek(0, 2)
        size = handle.tell()
        handle.seek(max(0, size - count))
        return handle.read()


def valid_job_id(value):
    if type(value) not in (int, str) or not re.fullmatch(r'[1-9][0-9]*', str(value)):
        raise ValueError('Job ID must be a positive integer without array/task suffixes')
    return str(value)


def resolve_job_id(explicit=None):
    receipt_path = LAUNCH / 'SUBMITTED.json'
    receipt_id = None
    if receipt_path.is_file():
        receipt = json.loads(receipt_path.read_text())
        receipt_id = valid_job_id(receipt['job_id'])
    explicit_id = valid_job_id(explicit) if explicit is not None else None
    if explicit_id and receipt_id and explicit_id != receipt_id:
        raise ValueError('Explicit job ID disagrees with this launch submission receipt')
    if not (explicit_id or receipt_id):
        raise ValueError('No SUBMITTED.json; provide an explicit --job-id')
    return explicit_id or receipt_id


def query(command):
    """A transient scheduler failure never supplies evidence of termination."""
    try:
        return subprocess.run(command, capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired) as error:
        return subprocess.CompletedProcess(command, 1, '', str(error))


def read_progress(result):
    path = LAUNCH / 'progress.json'
    if path.is_file():
        try:
            result['pipeline_progress'] = json.loads(path.read_text())
        except (OSError, ValueError) as error:
            result['warnings'].append({'progress_read_error': str(error)})


def snapshot(seen, job_id):
    job_id = valid_job_id(job_id)
    queue = query(['squeue', '-h', '-j', job_id, '-o', '%i|%j|%T|%M|%b|%R'])
    result = dict(utc=datetime.now(timezone.utc).isoformat(), job_id=job_id,
                  queue=queue.stdout.strip(), queue_error=queue.stderr.strip(),
                  queue_returncode=queue.returncode, new_epochs=[], live_bars={},
                  completed_counts={}, warnings=[], terminal=False)
    result['inherited_pretraining'] = {
        'completed_epochs': 600, 'source_run': str(PRETRAIN_SOURCE),
        'label': 'Completed previously; reused, not trained again in this job',
    }
    path = RUN / METRICS
    records = epoch_records(path.read_bytes()) if path.is_file() else []
    if not 0 <= seen['finetune'] <= len(records):
        raise ValueError('Fine-tuning cursor exceeds the available complete history')
    result['completed_counts']['finetune'] = len(records)
    for value in records:
        if value['epoch'] > seen['finetune']:
            result['new_epochs'].append(dict(value, stage='finetune'))
            bad = nonfinite_fields(value)
            if bad:
                result['warnings'].append(dict(stage='finetune', epoch=value['epoch'],
                                               nonfinite_fields=bad))
            seen['finetune'] = value['epoch']
    log_tail = tail(RUN / 'logs/finetune.log')
    bar = last_bar(log_tail)
    activity = last_finetune_activity(log_tail)
    if bar:
        result['live_bars']['finetune'] = bar
    if activity:
        result['live_bars']['finetune_activity'] = activity
    read_progress(result)
    result['pipeline_outputs'] = {name: (RUN / 'logs' / (name + '.log')).is_file()
                                  for name in ('finetune', 'select', 'test', 'verify')}
    # File existence alone is neither verification nor evidence of job success.
    result['test_complete_receipt_exists'] = (RUN / 'benchmark/TEST_COMPLETE.json').is_file()
    if queue.returncode == 0 and not queue.stdout.strip():
        accounting = query(['sacct', '-X', '-n', '-P', '-j', job_id,
                            '--format=JobIDRaw,State,ExitCode,Elapsed'])
        result['accounting'] = accounting.stdout.strip()
        result['accounting_error'] = accounting.stderr.strip()
        result['accounting_returncode'] = accounting.returncode
        if accounting.returncode == 0:
            for row in accounting.stdout.splitlines():
                fields = row.split('|')
                state_tokens = fields[1].split() if len(fields) >= 3 else []
                if fields[0].strip() == job_id and state_tokens:
                    state = state_tokens[0].rstrip('+')
                    if state in TERMINAL:
                        result['terminal'] = True
                        result['terminal_state'] = state
                        result['exit_code'] = fields[2]
        if result['terminal']:
            result['stderr_tail'] = tail(LAUNCH / 'logs' / f'vxc-{job_id}.err', 4000).decode(errors='replace')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--once', action='store_true')
    parser.add_argument('--job-id')
    parser.add_argument('--after-finetune', type=int, default=0)
    args = parser.parse_args()
    if not 0 <= args.after_finetune <= 600:
        parser.error('--after-finetune must be between 0 and 600')
    try:
        job_id = resolve_job_id(args.job_id)
    except (OSError, ValueError, KeyError) as error:
        parser.error(str(error))
    seen = {'finetune': args.after_finetune}
    while True:
        record = snapshot(seen, job_id)
        print(json.dumps(safe_json(record), allow_nan=False), flush=True)
        if args.once or record['terminal']:
            return
        time.sleep(20)


if __name__ == '__main__':
    main()
