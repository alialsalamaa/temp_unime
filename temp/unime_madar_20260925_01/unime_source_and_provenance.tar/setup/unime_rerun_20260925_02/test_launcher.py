"""CPU-only launch guards; no real scheduler/GPU operation."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('restart_launcher', Path(__file__).with_name('launcher.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class LaunchTests(unittest.TestCase):
    def rows(self):
        return [dict(type='pretrain', epoch=e, train_recon_loss=.2) for e in range(1, 601)] + [
            dict(type='pretrain_ema', epoch=600)]

    def test_pretraining_complete(self):
        m.validate_pretrain_rows(self.rows())

    def test_missing_epoch_rejected(self):
        with self.assertRaises(RuntimeError):
            m.validate_pretrain_rows(self.rows()[1:])

    def test_duplicate_epoch_rejected(self):
        with self.assertRaises(RuntimeError):
            m.validate_pretrain_rows(self.rows() + self.rows()[:1])

    def test_nonfinite_rejected(self):
        rows = self.rows()
        rows[30]['train_recon_loss'] = float('nan')
        with self.assertRaises(RuntimeError):
            m.validate_pretrain_rows(rows)

    def test_final_ema_required(self):
        with self.assertRaises(RuntimeError):
            m.validate_pretrain_rows(self.rows()[:-1])


    def test_cancelled_predecessors_include_latest_interrupted_run(self):
        self.assertEqual(m.CANCELLED_PREDECESSORS, ('11483', '11547', '11769', '11856'))
        with patch.object(m, 'accounting', side_effect=lambda job: [[job, 'CANCELLED by 1008', '0:0']]) as query:
            m.cancelled_predecessors()
            self.assertEqual([call.args[0] for call in query.call_args_list], list(m.CANCELLED_PREDECESSORS))

    def test_latest_predecessor_must_be_cancelled(self):
        def rows(job):
            return [[job, 'RUNNING' if job == '11769' else 'CANCELLED', '0:0']]
        with patch.object(m, 'accounting', side_effect=rows):
            with self.assertRaisesRegex(RuntimeError, '11769'):
                m.cancelled_predecessors()


    def test_replacement_11856_must_be_cancelled(self):
        for state in ('RUNNING', 'PENDING', 'COMPLETED', 'FAILED', None):
            def rows(job):
                if job == '11856':
                    return [] if state is None else [[job, state, '0:0']]
                return [[job, 'CANCELLED by 1008', '0:0']]
            with self.subTest(state=state), patch.object(m, 'accounting', side_effect=rows):
                with self.assertRaisesRegex(RuntimeError, '11856'):
                    m.cancelled_predecessors()

    def test_new_identity_and_cached_pretraining_are_separate(self):
        self.assertEqual(m.TAG, 'unime_rerun_20260925_02')
        self.assertEqual(m.ROOT.name, m.TAG)
        self.assertEqual(m.RUN.name, m.TAG)
        self.assertEqual(m.OLD_RUN.name, 'unime_20260923_01')
        self.assertIn('--comment=' + m.TAG + ':fresh-finetune', m.submission_command())

    def test_scope_conflicts(self):
        rows = [['1', 'vxc', 'RUNNING', 'gpu:1', '(null)'],
                ['2', 'renamed', 'PENDING', 'gpu:1', 'unime_20260923_01:full'],
                ['3', 'unrelated', 'RUNNING', 'gpu:2', '(null)']]
        self.assertEqual([r[0] for r in m.conflicting_jobs(rows)], ['1', '2'])
        self.assertEqual([r[0] for r in m.conflicting_jobs(rows, '1')], ['2'])

    def test_one_gpu_job_command(self):
        command = m.submission_command()
        self.assertEqual(command[0], 'sbatch')
        self.assertIn('--job-name=vxc', command)
        self.assertIn('--gres=gpu:nvidia_h200:1', command)
        self.assertIn('--ntasks=1', command)
        self.assertIn('--no-requeue', command)
        self.assertFalse(any('array' in item or 'dependency' in item for item in command))

    def test_exclusive_preserves_existing(self):
        with tempfile.TemporaryDirectory(prefix='restart_test.') as directory:
            path = Path(directory) / 'proof.json'
            m.exclusive(path, {'first': 1})
            with self.assertRaises(FileExistsError):
                m.exclusive(path, {'replacement': 2})
            self.assertEqual(m.read(path), {'first': 1})

    def test_inventory_detects_mutation(self):
        with tempfile.TemporaryDirectory(prefix='restart_test.') as directory:
            path = Path(directory) / 'proof.json'
            m.exclusive(path, {'first': 1})
            m.checked_inventory(Path(directory), {'proof.json': m.sha(path)})
            with self.assertRaises(RuntimeError):
                m.checked_inventory(Path(directory), {'proof.json': '0' * 64})

    def test_inventory_rejects_escape(self):
        with tempfile.TemporaryDirectory(prefix='restart_test.') as directory:
            with self.assertRaises(RuntimeError):
                m.checked_inventory(Path(directory), {'../escape': '0' * 64})

    def test_single_use_submission(self):
        with tempfile.TemporaryDirectory(prefix='restart_test.') as directory:
            with patch.object(m, 'ROOT', Path(directory)), \
                    patch.object(m, 'verify_source', return_value='manifest'), \
                    patch.object(m, 'verify_pretraining', return_value={}), \
                    patch.object(m, 'verify_old_smoke', return_value={}), \
                    patch.object(m, 'cancelled_predecessors'), \
                    patch.object(m, 'check_queue', return_value=[]), \
                    patch.object(m, 'fresh_run_path'), \
                    patch.object(m.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, '12345\n', '')) as submit:
                m.submit()
                self.assertEqual(m.read(Path(directory) / 'SUBMITTED.json')['job_id'], '12345')
                with self.assertRaises(FileExistsError):
                    m.submit()
                self.assertEqual(submit.call_count, 1)

    def test_ambiguous_response_never_retries(self):
        with tempfile.TemporaryDirectory(prefix='restart_test.') as directory:
            with patch.object(m, 'ROOT', Path(directory)), \
                    patch.object(m, 'verify_source', return_value='manifest'), \
                    patch.object(m, 'verify_pretraining', return_value={}), \
                    patch.object(m, 'verify_old_smoke', return_value={}), \
                    patch.object(m, 'cancelled_predecessors'), \
                    patch.object(m, 'check_queue', return_value=[]), \
                    patch.object(m, 'fresh_run_path'), \
                    patch.object(m.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, '', '')) as submit:
                with self.assertRaises(RuntimeError):
                    m.submit()
                with self.assertRaises(FileExistsError):
                    m.submit()
                self.assertEqual(submit.call_count, 1)
                self.assertFalse((Path(directory) / 'SUBMITTED.json').exists())

    def test_full_uses_native_pipeline_only(self):
        import inspect
        source = inspect.getsource(m.full)
        self.assertIn("['bash', 'scripts/finetune.sh', '--benchmark_protocol', str(protocol)]", source)
        self.assertIn("for mode in ('select', 'test', 'verify'):", source)
        self.assertIn("'val': 125", source)
        self.assertNotIn('scripts/pretrain.sh', source)
        self.assertNotIn('sbatch', source)
        self.assertNotIn('scancel', source)
        self.assertNotIn('torch.load', source)


if __name__ == '__main__':
    unittest.main()
