# UniME clean fine-tuning restart — 2026-09-25

User-approved plan: reuse the completed 600-epoch pretraining from job 11547;
restart fine-tuning from epoch 1 for all 600 epochs, then select and test.
One job named `vxc`, one H200. No separate smoke allocation. Proven submission-quota
rejections may retry every 30 minutes under the existing user authorization;
retries stop permanently upon acceptance. No automatic job restart/resubmission.

The unchanged native fine-tuning entrypoint loads the pretraining EMA-best
UniEncoder checkpoint (selected at pretraining epoch 593), filters encoder
weights, and initializes a new fine-tuning model/optimizer/scheduler/EMA.
It does not load any interrupted fine-tuning weights or state. Reusing this
fixed completed pretraining stage is equivalent to caching a completed stage,
not a late-stage weights-only resume. Exact numerical reproducibility is not
guaranteed. This restart must not be treated as an extra seed from which to
cherry-pick the better run: the interrupted fine-tuning candidates are excluded.

The architecture and approved paper-first training recipe remain byte-for-byte
unchanged: seed 40, batch 4, crop 96, 600 x 250 updates, AMP, compilation, EMA,
native optimizer and full scheduler, learning rates and augmentation. Original
98-file manifest, old smoke evidence and pretrained checkpoint are hash checked.
Only orchestration/observation is new, outside the frozen model repository.

Pipeline inside the single allocation:

1. Verify job identity, one visible GPU, source and pretraining provenance.
2. Run six-step compiled fine-tuning smoke in a separate process.
3. Validate/reuse prepared data and prepare the same split protocol.
4. Fresh fine-tuning for 600 epochs, capturing the native 24 EMA candidates.
5. Select one checkpoint on original 80 validation cases x 15 combinations,
   using mean raw WT/TC/ET Dice with the approved original-grid metric rules.
6. Test only that frozen checkpoint on 251 cases x 15 combinations and verify.

Exact split: 875 training, 125 validation (80 selection + 45 development), 251
test cases. Native all-four-modality validation diagnostics use all 125, so the
45 cases are not an untouched lockbox. These are cases, not necessarily unique
patients. Historical test results were previously inspected; not a new blind
holdout. The current source remains the approved local paper-first adaptation,
not a claim of independently certified author reproduction.

Original jobs 11547, 11769 and 11856 and their artifacts remain intact. Job 11769 was
cancelled after 134 completed fine-tuning epochs, before any checkpoint save.
The replacement job 11856 was also cancelled during smoke before fine-tuning.
The user explicitly authorized another resubmission on 2026-09-25. This new run restarts
fine-tuning at epoch 1; it does not attempt to resume from epoch 134. User-cancelled t1 job 11483
retains 44 completed validation checkpoint evaluations (520–1380 every20).
Its remaining six checkpoints need an explicitly reviewed continuation later;
this launcher does not restart t1 or change unrelated jobs.

New run: `artifacts/unime/benchmark_runs/unime_rerun_20260925_02`.
Submission is single-use, exclusive-intent guarded. An ambiguous sbatch response
requires inspection, never an automatic second submission. Output must not exist.
