"""Single authorized allocation: cached pretraining, fresh fine-tuning, select, test."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
import traceback

BASE = Path('/adialab/usr/khaled/SAMTOK_DIR/AVMUR/baselines')
ROOT = BASE / 'setup/unime_rerun_20260925_02'
OLD_LAUNCH = BASE / 'setup/unime_launch_20260923_01'
REPO = BASE / 'UniME'
PYTHON = BASE / '.venv-unime/bin/python'
TAG = 'unime_rerun_20260925_02'
CANCELLED_PREDECESSORS = ('11483', '11547', '11769', '11856')
RUN = BASE / 'artifacts/unime/benchmark_runs' / TAG
OLD_RUN = BASE / 'artifacts/unime/benchmark_runs/unime_20260923_01'
OLD_SMOKE = BASE / 'artifacts/unime/smoke_runs/unime_20260923_01'
PRETRAIN = OLD_RUN / 'pretrain/BRATS2023-40-Normal/UniEncoder/ema_best_checkpoint.pth'
PRETRAIN_SHA = 'ef8404f658c542cb856e23b9dfb9291df3408d7d56931ec3db16b4df91180c1f'
OLD_MANIFEST_SHA = 'b3370c4a55e75ca109cd8e955cc658c8d4bc77204244d4bfe42e61642adbe109'
RAW = BASE / 'data/ASNR-MICCAI-BraTS2023-GLI-Challenge-TrainingData'
DATA = BASE / 'artifacts/unime/data/BRATS2023'
SPLIT = BASE / 'artifacts/splits/official_imfuse_split.json'
PARTITION = BASE / 'artifacts/unime/reference/validation_partition.json'
PREPROCESSOR = BASE / 'baseline_adapters/unime/preprocess_full.py'


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def exclusive(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def checked_inventory(base, files):
    for relative, expected in files.items():
        path = base / relative
        if (Path(relative).is_absolute() or path.is_symlink()
                or not path.resolve().is_relative_to(base.resolve()) or sha(path) != expected):
            raise RuntimeError('Frozen file changed or unsafe path: ' + relative)


def verify_source():
    if Path(__file__).resolve().parent != ROOT or ROOT.is_symlink() or ROOT.resolve() != ROOT:
        raise RuntimeError('Run only from the exact isolated remote launch directory')
    if sha(OLD_LAUNCH / 'manifest.json') != OLD_MANIFEST_SHA:
        raise RuntimeError('Original manifest changed')
    original = read(OLD_LAUNCH / 'manifest.json')
    checked_inventory(BASE, original['files'])
    capture = load('restart_source_inventory', REPO / 'source/benchmark_capture.py')
    if capture.source_fingerprints(REPO) != read(OLD_RUN / 'SOURCE_CONFIG_FROZEN.json')['source_sha256']:
        raise RuntimeError('Original source inventory changed, including added or removed files')
    manifest = read(ROOT / 'manifest.json')
    checked_inventory(ROOT, manifest['files'])
    if manifest['original_manifest_sha256'] != OLD_MANIFEST_SHA:
        raise RuntimeError('Incorrect original source pin')
    return sha(ROOT / 'manifest.json')


def validate_pretrain_rows(rows):
    training = [row for row in rows if row.get('type') == 'pretrain']
    if [row.get('epoch') for row in training] != list(range(1, 601)):
        raise RuntimeError('Pretraining did not complete all 600 epochs')
    if any(not math.isfinite(row['train_recon_loss']) for row in training):
        raise RuntimeError('Nonfinite pretraining loss')
    if not any(row.get('type') == 'pretrain_ema' and row.get('epoch') == 600 for row in rows):
        raise RuntimeError('Final pretraining EMA validation is absent')


def verify_pretraining():
    metrics = PRETRAIN.parent / 'UniEncoder_metrics.jsonl'
    validate_pretrain_rows([json.loads(line) for line in metrics.read_text().splitlines()])
    if PRETRAIN.is_symlink() or sha(PRETRAIN) != PRETRAIN_SHA:
        raise RuntimeError('Completed pretrained checkpoint changed')
    return dict(path=str(PRETRAIN), sha256=PRETRAIN_SHA, source_job='11547',
                completed_pretraining_epochs=600, selected_pretraining_epoch=593,
                selection='native_pretraining_ema_best_reconstruction_objective',
                metrics_sha256=sha(metrics), config_sha256=sha(PRETRAIN.parent / 'config.yaml'))


def verify_old_smoke():
    passed = read(OLD_SMOKE / 'SMOKE_PASSED.json')
    if (passed['status'] != 'passed' or passed['job_id'] != '11537'
            or passed['manifest_sha256'] != OLD_MANIFEST_SHA
            or passed['protocol_sha256'] != sha(OLD_SMOKE / 'protocol.json')
            or passed['test_cases_used_for_smoke_inference'] != 0):
        raise RuntimeError('Original smoke proof does not match')
    checked_inventory(OLD_SMOKE, passed['evidence_sha256'])
    rows = accounting('11537')
    if not any(row[:3] == ['11537', 'COMPLETED', '0:0'] for row in rows):
        raise RuntimeError('Original smoke allocation did not complete successfully')
    return dict(path=str(OLD_SMOKE / 'SMOKE_PASSED.json'), sha256=sha(OLD_SMOKE / 'SMOKE_PASSED.json'))


def accounting(job):
    result = subprocess.run(['sacct', '-X', '-n', '-P', '-j', job,
                             '--format=JobIDRaw,State,ExitCode'], capture_output=True, text=True, check=True)
    return [line.split('|') for line in result.stdout.splitlines() if line.strip()]


def cancelled_predecessors():
    for job in CANCELLED_PREDECESSORS:
        if not any(row[0] == job and row[1].startswith('CANCELLED') for row in accounting(job)):
            raise RuntimeError('Expected cancelled predecessor is not terminal: ' + job)


def conflicting_jobs(rows, current=None):
    return [row for row in rows if row[0] != current and (
        row[1].lower() in {'vxc', 'vcx', 't1'} or row[1].lower().startswith('unime')
        or 'unime_' in row[4].lower() or row[4].startswith('V11T1:'))]


def check_queue(current=None):
    result = subprocess.run(['squeue', '-h', '-u', 'khaled', '-o', '%i|%j|%T|%b|%k'],
                             capture_output=True, text=True, check=True)
    rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
    if any(len(row) != 5 for row in rows) or conflicting_jobs(rows, current):
        raise RuntimeError('Conflicting or unrecognized scoped job: ' + result.stdout)
    return rows


def fresh_run_path(path=RUN):
    if (not path.is_absolute() or path.exists() or path.is_symlink()
            or path.parent != BASE / 'artifacts/unime/benchmark_runs'
            or path.parent.resolve() != path.parent):
        raise RuntimeError('Output must be a new direct child of the fixed benchmark root')


def submission_command():
    return ['sbatch', '--parsable', '--job-name=vxc', '--chdir=' + str(ROOT),
            '--comment=' + TAG + ':fresh-finetune', '--partition=main', '--nodes=1',
            '--ntasks=1', '--gres=gpu:nvidia_h200:1', '--cpus-per-task=16', '--mem=192G',
            '--no-requeue', str(ROOT / 'full.slurm')]


def submit():
    manifest_sha = verify_source()
    pretrain = verify_pretraining()
    smoke = verify_old_smoke()
    cancelled_predecessors()
    queue = check_queue()
    fresh_run_path()
    command = submission_command()
    exclusive(ROOT / 'SUBMIT_INTENT.json', dict(created_utc=utc(), command=command,
        manifest_sha256=manifest_sha, pretraining=pretrain, prior_smoke=smoke, queue=queue,
        user_authorized='reuse_completed_pretraining_restart_finetuning_epoch1_for600_then_select_and_test',
        warning='Exactly one submission. Never retry blindly after an ambiguous response.'))
    environment = {key: value for key, value in os.environ.items() if not key.startswith('SBATCH_')}
    result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True)
    exclusive(ROOT / 'SBATCH_RESPONSE.json', dict(utc=utc(), returncode=result.returncode,
                                                 stdout=result.stdout, stderr=result.stderr))
    if result.returncode or not re.fullmatch(r'[0-9]+(?:;[^\s]+)?\s*', result.stdout):
        raise RuntimeError('Submission failed or ambiguous; inspect queue and receipt, do not auto-retry')
    job = result.stdout.strip().split(';')[0]
    exclusive(ROOT / 'SUBMITTED.json', dict(job_id=job, manifest_sha256=manifest_sha,
                                           created_utc=utc(), command=command))
    print(json.dumps(dict(job_id=job, name='vxc', gpus=1, run_dir=str(RUN))), flush=True)


def progress(stage, **extra):
    value = dict(stage=stage, updated_utc=utc(), job_id=os.environ.get('SLURM_JOB_ID'), **extra)
    temporary = ROOT / ('progress.' + str(os.getpid()) + '.tmp')
    exclusive(temporary, value)
    os.replace(temporary, ROOT / 'progress.json')
    print(json.dumps(value), flush=True)


def run(command, log):
    print('COMMAND ' + json.dumps(list(map(str, command))), flush=True)
    with Path(log).open('x') as handle:
        result = subprocess.run(list(map(str, command)), cwd=REPO, stdout=handle, stderr=subprocess.STDOUT)
    if result.returncode:
        print(Path(log).read_text(errors='replace')[-10000:], flush=True)
        raise RuntimeError('Stage failed: ' + str(log))


def configure_runtime():
    for key, folder in dict(XDG_CACHE_HOME='xdg', TORCH_HOME='torch', TRITON_CACHE_DIR='triton',
                            TORCHINDUCTOR_CACHE_DIR='inductor', CUDA_CACHE_PATH='cuda',
                            TORCH_EXTENSIONS_DIR='extensions', WANDB_DIR='wandb').items():
        path = ROOT / 'cache' / folder
        path.mkdir(parents=True, exist_ok=True)
        os.environ[key] = str(path)
    scratch = tempfile.mkdtemp(prefix='unime.' + os.environ['SLURM_JOB_ID'] + '.', dir='/tmp')
    for key in ('TMPDIR', 'TMP', 'TEMP'):
        os.environ[key] = scratch
    os.environ.update(UNIME_PYTHON=str(PYTHON), UNIME_DATA_PATH=str(DATA.parent),
                      UNIME_SEED='40', UNIME_WANDB_MODE='disabled', WANDB_MODE='disabled',
                      UNIME_GPU_IDS=os.environ['CUDA_VISIBLE_DEVICES'],
                      UNIME_PRETRAIN_CHECKPOINT=str(PRETRAIN),
                      UNIME_PRETRAIN_LOG_ROOT=str(OLD_RUN / 'pretrain'),
                      UNIME_FINETUNE_LOG_ROOT=str(RUN / 'finetune'))
    return scratch


def full():
    manifest_sha = verify_source()
    original = load('original_launch_helpers', OLD_LAUNCH / 'orchestrate.py')
    gpu = original.allocation()
    if any(key in os.environ for key in ('LOCAL_RANK', 'ACCELERATE_PROCESS_INDEX')):
        raise RuntimeError('No distributed launch allowed')
    receipt = original.submission_receipt(ROOT / 'SUBMITTED.json')
    if receipt['job_id'] != gpu['job_id'] or receipt['manifest_sha256'] != manifest_sha:
        raise RuntimeError('Wrong allocation or changed submitted launch')
    cancelled_predecessors()
    check_queue(gpu['job_id'])
    pretrain = verify_pretraining()
    smoke = verify_old_smoke()
    fresh_run_path()
    RUN.mkdir(exist_ok=False)
    (RUN / 'logs').mkdir()
    configure_runtime()
    protocol = RUN / 'protocol.json'
    candidates = RUN / 'finetune/BRATS2023-40-Normal/UniME/benchmark_candidates'
    results = RUN / 'benchmark'
    fine_command = ['bash', 'scripts/finetune.sh', '--benchmark_protocol', str(protocol)]
    exclusive(RUN / 'SOURCE_CONFIG_FROZEN.json', dict(created_utc=utc(), manifest_sha256=manifest_sha,
        original_manifest_sha256=OLD_MANIFEST_SHA, pretraining=pretrain, prior_smoke=smoke, gpu=gpu,
        commands=[fine_command], fine_tuning_epochs=600, updates_per_epoch=250, seed=40,
        optimizer='new_native_optimizer_from_step0', scheduler='new_native_full150000_update_schedule',
        ema='new_native_finetuning_EMA', reuse_old_finetune_weights=False,
        reuse_old_finetune_candidates=False, final_selection_cases=80, final_test_cases=251,
        validation_development_cases=45, modality_configurations=15, tested_checkpoints=1,
        randomness='new_seed40_process_no_exact_bitwise_reproducibility_claim',
        disclosure='Historical test results were previously inspected; not a new blind holdout',
        environment={key: value for key, value in os.environ.items() if key.startswith('UNIME_')},
        source_status='existing_local_paper_configuration_not_certified_author_reproduction'))
    progress('gpu_finetuning_smoke', run_dir=str(RUN))
    smoke_log = RUN / 'logs/restart_smoke.log'
    run([PYTHON, '-B', REPO / 'scripts/smoke_training_gpu.py', '--stage', 'finetune', '--compile', '--steps', '6'], smoke_log)
    proof = original.latest_pass(smoke_log, 'finetune')
    exclusive(RUN / 'RESTART_SMOKE_PASSED.json', dict(completed_utc=utc(), result=proof,
              log_sha256=sha(smoke_log), separate_process=True, training_epochs_consumed=0, **gpu))
    verify_source()
    previous = {}
    for name in ('preprocessing_report.json', 'run_manifest.json', 'status.json'):
        path = BASE / 'artifacts/unime/preprocessing' / name
        if path.is_file():
            previous[name] = dict(source=str(path), sha256=sha(path), content=read(path))
    exclusive(RUN / 'PREPROCESSING_PREVIOUS_RECORDS.json', previous)
    progress('preprocessing')
    run([PYTHON, '-B', PREPROCESSOR, '--workers', '4'], RUN / 'logs/preprocessing.log')
    report = read(BASE / 'artifacts/unime/preprocessing/preprocessing_report.json')
    if not (report.get('status') == 'passed' and report.get('cases_validated') == 1251
            and report.get('arrays_validated') == 2502 and report.get('full_value_scan_passed') is True):
        raise RuntimeError('Preprocessing validation incomplete')
    exclusive(RUN / 'PREPROCESSING_PASSED.json', report)
    verify_source()
    progress('protocol')
    run([PYTHON, '-B', REPO / 'scripts/prepare_benchmark.py', '--split-json', SPLIT,
         '--validation-partition', PARTITION, '--data-root', DATA, '--raw-data-root', RAW,
         '--output', protocol], RUN / 'logs/protocol.log')
    prepared = read(protocol)
    expected_counts = {'train': 875, 'val': 125, 'selection80': 80, 'development45': 45, 'test': 251}
    actual_counts = {key: len(value) for key, value in prepared['case_ids'].items()}
    if actual_counts != expected_counts:
        raise RuntimeError('Unexpected protocol populations: ' + repr(actual_counts))
    protocol_sha = sha(protocol)
    exclusive(RUN / 'PROTOCOL_FROZEN.json', dict(path=str(protocol), sha256=protocol_sha))

    def check():
        verify_source()
        if sha(protocol) != protocol_sha:
            raise RuntimeError('Protocol changed')

    check()
    verify_pretraining()
    progress('finetuning', epochs=600, pretraining_reused_epochs=600, run_dir=str(RUN))
    run(fine_command, RUN / 'logs/finetune.log')
    for mode in ('select', 'test', 'verify'):
        check()
        progress(mode)
        run([PYTHON, '-B', REPO / 'scripts/run_benchmark.py', mode,
             '--candidates', candidates, '--output', results], RUN / ('logs/' + mode + '.log'))
    check()
    if not (results / 'TEST_COMPLETE.json').is_file():
        raise RuntimeError('No complete one-checkpoint test receipt')
    exclusive(RUN / 'COMPLETE.json', dict(completed_utc=utc(), job_id=gpu['job_id'],
              test_complete_sha256=sha(results / 'TEST_COMPLETE.json'), verification_exit_code=0))
    progress('complete', run_dir=str(RUN))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('verify', 'submit', 'full'))
    args = parser.parse_args()
    if args.mode == 'verify':
        print(json.dumps(dict(manifest_sha256=verify_source(), pretraining=verify_pretraining(),
                              prior_smoke=verify_old_smoke())), flush=True)
    elif args.mode == 'submit':
        submit()
    else:
        try:
            full()
        except BaseException:
            progress('failed', traceback=traceback.format_exc())
            raise


if __name__ == '__main__':
    main()
